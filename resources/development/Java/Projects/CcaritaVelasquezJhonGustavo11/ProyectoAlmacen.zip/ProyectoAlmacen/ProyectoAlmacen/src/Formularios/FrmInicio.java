package Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
public class FrmInicio extends javax.swing.JFrame {
    private Conectar conexionBD; // Crear una instancia de la clase Conexion
    private int intentosFallidos = 0;
    public FrmInicio() {
        initComponents();
        this.setLocationRelativeTo(null);
        conexionBD = new Conectar(); // Inicializar la conexión
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        TxtUser = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        TxtPswd = new javax.swing.JPasswordField();
        BtnCancelar = new javax.swing.JButton();
        BtnInicioSesion = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Usuario");

        jLabel2.setText("Clave");

        BtnCancelar.setText("Cancelar");
        BtnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCancelarActionPerformed(evt);
            }
        });

        BtnInicioSesion.setText("Iniciar Sesión");
        BtnInicioSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnInicioSesionActionPerformed(evt);
            }
        });

        jLabel3.setBackground(new java.awt.Color(255, 0, 51));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setText("Inicio de Sesión");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(BtnInicioSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(BtnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(TxtPswd)
                    .addComponent(jLabel2)
                    .addComponent(TxtUser)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 288, Short.MAX_VALUE))
                .addContainerGap(193, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(TxtUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(TxtPswd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtnInicioSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(209, 209, 209))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnInicioSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnInicioSesionActionPerformed
        // TODO add your handling code here:
        String usuario = this.TxtUser.getText();  // Obtiene el texto del campo de usuario
        String contrasena = new String(this.TxtPswd.getPassword());  // Obtiene el texto del campo de contraseña
        // Llama al método para iniciar sesión
        iniciarSesion(usuario, contrasena);
    }//GEN-LAST:event_BtnInicioSesionActionPerformed

    private void BtnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCancelarActionPerformed
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_BtnCancelarActionPerformed
// Método para realizar la validación de inicio de sesión
    private void iniciarSesion(String usuario, String contrasena) {
        
        if (intentosFallidos >= 4) {
            JOptionPane.showMessageDialog(this, "Has superado el número máximo de intentos. Acceso denegado.");
            BtnInicioSesion.setEnabled(false); // Deshabilita el botón para que no pueda intentar más
            return; // Salimos del método para no hacer más validaciones
        }
        // Conexión a la base de datos
        Connection conexion = conexionBD.getConexion();

        // Consulta SQL para validar usuario y contraseña
        String consultaSQL = "SELECT * FROM TUsuarios WHERE usuario = ? AND clave = ?";

        try (PreparedStatement sentencia = conexion.prepareStatement(consultaSQL)) {
            // Asignar los parámetros de la consulta SQL
            sentencia.setString(1, usuario);
            sentencia.setString(2, contrasena);

            // Ejecutar la consulta y obtener el resultado
            ResultSet resultado = sentencia.executeQuery();

            if (resultado.next()) {
                // Si hay un resultado, las credenciales son correctas
                JOptionPane.showMessageDialog(this, "Inicio de sesión exitoso.");
                
                // Abrir el formulario FrmMenu y cerrar el formulario actual (LoginForm)
                FrmMenu menu = new FrmMenu(); // Asumiendo que FrmMenu es el nombre de tu formulario principal
                menu.setExtendedState(JFrame.MAXIMIZED_BOTH);
                menu.setVisible(true);  // Muestra el formulario principal
                this.dispose();  // Cierra el formulario de inicio de sesión

            } else {
                // Si no encontró, el usuario o contraseña son incorrectos
                intentosFallidos++; // Incrementamos el contador de intentos fallidos

                if (intentosFallidos == 4) {
                    // Si llegó al 4to intento fallido, bloquear y avisar
                    JOptionPane.showMessageDialog(this, "Has superado el número máximo de intentos. Acceso denegado.");
                    BtnInicioSesion.setEnabled(false); // Deshabilitar botón para evitar más intentos
                } else {
                    // Mostrar mensaje con el número de intento actual
                    JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos. Intento " + intentosFallidos + " de 4.");
                }
            }

        } catch (SQLException ex) {
            // Manejo de errores SQL
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error en la conexión a la base de datos.");
        } finally {
            // Cerrar la conexión después de usarla
            conexionBD.cerrarConexion();
        }
    }


    public static void main(String args[]) {
        // Crear y mostrar el formulario
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmInicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnCancelar;
    private javax.swing.JButton BtnInicioSesion;
    private javax.swing.JPasswordField TxtPswd;
    private javax.swing.JTextField TxtUser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}